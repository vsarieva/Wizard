const CONFIG = {
    PORT: 3001,
    DB_URL: 'mongodb://localhost:27017/skeleton', //localhost = 127.0.0.1
   // DB_URL: 'mongodb://127.0.0.1:27017/skeleton', //localhost = 127.0.0.1
   SECRET: '748f2c72-0a5a-41da-b69d-fe47108a1f20',
}

module.exports = CONFIG; 